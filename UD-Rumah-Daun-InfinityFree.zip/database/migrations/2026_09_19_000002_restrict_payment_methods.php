<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (DB::getDriverName() === 'mysql') {
            DB::table('transactions')
                ->whereIn('payment_method', ['transfer', 'ewallet'])
                ->update(['payment_method' => 'cash']);

            DB::statement("ALTER TABLE transactions MODIFY payment_method ENUM('cash', 'qris') NULL");
        }
    }

    public function down(): void
    {
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE transactions MODIFY payment_method ENUM('cash', 'transfer', 'qris', 'ewallet') NULL");
        }
    }
};